//6206021620086 นางสาวชนิภรณ์ ศิริสุข
package com.example.countnumberapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    TextView numCount;
    Button countUp, countDown, btnReset;

    final String message = "0";
    int count = 0, add, minus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numCount = (TextView) findViewById(R.id.numCount);

        countUp = (Button) findViewById(R.id.countUp);
        countDown = (Button) findViewById(R.id.countDown);
        btnReset = (Button) findViewById(R.id.btnReset);

        countUp.setOnClickListener(this);
        countDown.setOnClickListener(this);
        btnReset.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String mes = "Hello", txtCount = "";
        int result ;

        if (v.getId() == R.id.countUp){
            add = 1;
            result = count + add;

            String i = Integer.toString(result);

            numCount.setText(i);
            count++;
            if (count % 5 == 0){
                Toast.makeText(this, count + " is divisible by 5.",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else if  (v.getId() == R.id.countDown) {
            minus = 1;
            result = count - minus;

            String i = Integer.toString(result);

            numCount.setText(i);
            count--;
            if (count % 5 == 0){
                Toast.makeText(this, count + " is divisible by 5.",
                        Toast.LENGTH_SHORT).show();

            }
        }
        else if (v.getId() == R.id.btnReset) {
            numCount.setText(message);
            count = 0;
        }
    }
}